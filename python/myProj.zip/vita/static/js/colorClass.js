var colorList = [
    'w3-red', 'w3-pink', 'w3-purple', 'w3-deep-purple', 'w3-indigo',
    'w3-blue', 'w3-aqua', 'w3-teal', 'w3-green', 'w3-light-green', 
    'w3-lime', 'w3-khaki', 'w3-yellow', 'w3-amber', 'w3-orange', 'w3-deep-orange'
];