"""
URL configuration for vita project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import ListView, DetailView
from myPw.models import Mypw

from myPw.views import *
from main.views import *

urlpatterns = [
    path('admin/', admin.site.urls),

    # myPw 일반 사용자 뷰 요청
    path('myPw/', MypwLV.as_view(), name='index'),
    path('myPw/<int:pk>/', MypwDV.as_view(), name='detail'),

    path('myPw/', ListView.as_view(model=Mypw), name='index'),
    path('myPw/<int:pk>/', DetailView.as_view(model=Mypw), name='detail'),

    # bar 요청 처리
    path('bar/', include('bar.urls')),

    # main 뷰 요청처리
    path('', MainView.as_view(), name="main"),

    # member 뷰 요청처리
    path('member/', include('member.urls')),

    # gallery 뷰 요청처리
    path('gallery/', include('gallery.urls')),
]
