from django.shortcuts import render, redirect
from django.http import HttpResponse
import oracledb as db
db.init_oracle_client() # oracle driver "thick" type으로 변경

from member.models import *
from django.db.models import *

# Create your views here.
def logout(req):
    req.session['SID'] = None
    return redirect('/')

def loginForm(req):
    return render(req, 'login.html', {})

def loginProc(req):
    if req.method == 'GET':
        return redirect('/member/login/')
    else:
        # POST 방식으로 전달된 경우
        # 파라미터 꺼내고
        sid = req.POST.get('id', None)
        spw = req.POST.get('pw', None)
        # print(sid, ' : ', spw)
        # print(Member)
        try:
            memb = Member.objects.filter(id=sid, pw=spw).aggregate(Count('id'))
            cnt = memb['id__count']
            if cnt == 1:
                req.session['SID'] = sid
                return redirect('/')
            else:
                return redirect('/member/login/')
        except:
            return redirect('/member/login/')
        
        # dict1 = {
        #     'id': sid,
        #     'pw': spw
        # }

        # 데이터베이스 조회하고
        # cnt = dbProc(getSQL('LOGIN', dict1))
        # # 결과에 따라 처리하고
        # if cnt == 1:
        #     # 정보에 맞는 회원이 있는 경우
        #     # 세션에 아이디 기억시키고
        #     req.session['SID'] = sid
        #     return redirect('/')
        # else:
        #     # 정보가 맞지 않는 경우
        #     return redirect('/member/login/')
            

def dbProc(sql):
    con = db.connect(user='jennie', password='12345', dsn='localhost:1521/xe')
    cursor = con.cursor()
    cursor.execute(sql)
    cnt = cursor.fetchone()
    return cnt[0]

def getSQL(code, d1):
    if code == 'LOGIN':
        return """
                SELECT
                    COUNT(*)
                FROM
                    member
                WHERE
                    id = '%s'
                    AND pw = '%s'""" % (d1['id'], d1['pw'])
    elif code == 'JOIN':
        return """
                    INSERT INTO
                        member(mno, name, id, pw, mail, tel, gen, avatar)
                    VALUES(
                        mnoseq.NEXTVAL, '%s', '%s', '%s', '%s', '%s', '%s', %d
                    )
                    """ % (d1['name'], d1['id'], d1['pw'], d1['mail'], d1['tel'], d1['gen'], d1['ano'])