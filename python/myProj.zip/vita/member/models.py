from django.db import models

# Create your models here.

class Avatar(models.Model):
    ano = models.IntegerField('ano', primary_key=True)
    filename = models.CharField('filename', max_length=300, blank=False)
    dir = models.CharField('dir', max_length=300, blank=False)
    len = models.IntegerField('len', blank=True)
    gen = models.CharField('gen', max_length=1, blank=False)
    isshow = models.CharField('isshow', max_length=1, blank=False)
    
    def __str__(self):
        return str(self.ano) + ' - ' + self.filename
    
    class Meta:
        managed = False
        db_table = 'avatar'

class Member(models.Model):
    mno = models.IntegerField('mno', primary_key=True)
    name = models.CharField('name', max_length=15, blank=False)
    id = models.CharField('id', max_length=10, blank=False, unique=True)
    pw = models.CharField('pw', max_length=12, blank=False)
    mail = models.CharField('mail', max_length=30, blank=False, unique=True)
    tel = models.CharField('tel', max_length=13, blank=False, unique=True)
    joindate = models.DateField('joindate', blank=False)
    gen = models.CharField('gen', max_length=1, blank=False)
    ano = models.ForeignKey(Avatar, 
                            to_field='ano',
                            db_column = 'avatar',
                            on_delete=models.CASCADE,
                            null = False
                            )
    isshow = models.CharField('isshow', max_length=1, blank=False)

    def __str__(self):
        return str(self.mno) + ' - ' + self.id
    
    class Meta:
        managed = False
        db_table = 'member'
