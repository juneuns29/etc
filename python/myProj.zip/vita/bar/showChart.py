import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO

import plotly.express as px

def chart1():
    fig, ax = plt.subplots()

    fruits = ['apple', 'blueberry', 'cherry', 'orange']
    counts = [40, 100, 30, 55]
    bar_labels = ['pink', 'blue', 'red', 'orange']
    bar_colors = ['tab:pink', 'tab:blue', 'tab:red', 'tab:orange']

    ax.bar(fruits, counts, label=fruits, color=bar_colors)

    ax.set_xlabel('fruit')
    ax.set_ylabel('fruit counts')
    ax.set_title('Fruit supply by kind and color')
    ax.legend(title='Fruit color')

    buff = BytesIO()
    plt.savefig(buff, format='jpg')
    buff.seek(0)
    return buff

def chart2():
    fruits = ['apple', 'blueberry', 'cherry', 'orange']
    counts = [40, 100, 30, 55]
    bar_colors = ['tab:red', 'tab:blue', 'tab:red', 'tab:orange']
    df = pd.DataFrame({'fruits': fruits, 'counts': counts})

    fig = px.bar(df, x='fruits', y='counts', color='counts', hover_name='fruits')
                    # ,size='counts', color='counts', hover_name='fruits', log_x=True, size_max=60)
    plot_tag = fig.to_html(full_html=False)

    return plot_tag

