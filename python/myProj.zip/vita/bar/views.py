from django.shortcuts import render
from django.core import serializers
from django.http import HttpResponse
from django.views.generic import TemplateView
import json
from dataclasses import dataclass, asdict, field, fields

from io import BytesIO
import plotly.express as px

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from myPw.models import Mypw
from . import black, showChart

# a1/ 요청 처리 - 클래스로 처리
class A1(TemplateView):
    # html 파일 지정
    template_name = 'bar/abc.html'

# b1/ 요청 처리 - 함수로 처리
def gibon(req): # req: 매개변수
    return render(req, 'bar/efg.html', {})

# json 응답 받기 - barData/ 요청 처리
def getBarData(req):
    # bData = Mypw.objects.order_by('urlname')
    # dList = serializers.serialize('json', bData)
    # return HttpResponse(dList)

    # if req.method == 'GET':
    #     req.GET['payLoad']
    # else:
    #     req.POST['payLoad']

    d1 = black.Memb().toDict()
    dList = json.dumps(d1, indent=4)
    return HttpResponse(dList)

def chart1(req):
    imgBuff = showChart.chart1()
    return HttpResponse(imgBuff.getvalue(), content_type='image/jpg')

def chart2(req):
    tag_data = showChart.chart2()
    return render(req, 'bar/lmn.html', {'tag_data': tag_data})
