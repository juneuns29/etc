class Memb:
    def __init__(self):
        self.name = 'jennie'
        self.age = 28
        self.gen = 'F'
        self.mail = 'jennie@human.com'

    def toDict(self):
        return {
            'name': self.name,
            'age': self.age,
            'gen': self.gen,
            'mail': self.mail
        }

