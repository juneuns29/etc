from django.contrib import admin
from django.urls import path, include
from django.views.generic import ListView, DetailView
from myPw.models import Mypw

from . import views

urlpatterns = [
    path('a1/', views.A1.as_view(), name='a1'),
    path('b1/', views.gibon, name='b1'),
    path('getJson/', views.getBarData, name='getData'),
    path('showChart1/', views.chart1, name="chart1"),
    path('showChart2/', views.chart2, name="chart2"),
]
