from django.db import models

from member.models import *

# Create your models here.
class Gallery(models.Model):
    gno = models.IntegerField(db_column='gal_no', primary_key=True)
    gwriter = models.ForeignKey(
                                    Member,
                                    to_field='id',
                                    db_column='gal_writer',
                                    on_delete = models.CASCADE,
                                    null = False
                                )
    gbody = models.CharField(db_column='gal_body', max_length=4000, blank=False)
    gdate = models.DateField(db_column='gal_wdate', blank=False)
    gcount = models.IntegerField(db_column='gal_count', default=0, null=False)
    gupno = models.IntegerField(db_column='gal_upno', default=0)
    gisshow = models.CharField(db_column="gal_isshow", max_length=1, default='Y', blank=False)

    def __str__(self):
        return self.gwriter
    
    class Meta:
        managed = False
        db_table = 'gallery'

class Photo(models.Model):
    pno = models.IntegerField(db_column='pno', primary_key=True)
    galno = models.ForeignKey(
        Gallery,
        to_field = 'gno',
        db_column = 'galno',
        on_delete = models.CASCADE,
        related_name='gal',
        null = False
    )
    oriname = models.CharField(db_column='photo_oname', max_length=300, null=False)
    savename = models.CharField(db_column='photo_sname', max_length=300, null=False)
    dir = models.CharField(db_column='photo_dir', max_length=200, default='/image/gallery/', null=False)
    pdate = models.DateField(db_column='p_date', blank=False)
    pisshow = models.CharField(db_column='p_isshow', max_length=1, default='Y', null=False)

    def __str__(self):
        return str(self.pno) + ' : ' + self.savename
    
    class Meta:
        managed = False
        db_table = 'photo'
