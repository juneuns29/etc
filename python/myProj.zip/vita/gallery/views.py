from django.shortcuts import render
from django.http import *
from django.views.generic import TemplateView, ListView

from .models import *
# Create your views here.

# gallery list view
def galleryList(req):
    plist = Photo.objects.select_related('galno').filter(pisshow='Y').all().order_by('-pdate')
    
    return render(req, 'gallery.html', {'plist': plist})
