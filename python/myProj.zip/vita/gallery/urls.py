from django.contrib import admin
from django.urls import path, include
from django.views.generic import ListView, DetailView

from main.views import *
from . import views

urlpatterns = [
    # gallery 뷰 요청처리
    path('list/', views.galleryList, name='gallery'),
]
