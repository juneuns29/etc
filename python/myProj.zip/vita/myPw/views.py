from django.shortcuts import render
from django.views.generic import ListView, DetailView
from myPw.models import Mypw

# list View
class MypwLV(ListView):
    model = Mypw

# detail view
class MypwDV(DetailView):
    model = Mypw
