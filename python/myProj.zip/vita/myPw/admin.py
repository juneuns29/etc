from django.contrib import admin
from myPw.models import Mypw

# Register your models here.

@admin.register(Mypw)
class MypwAdmin(admin.ModelAdmin):
    list_display = ('id', 'urlname', 'pw')
