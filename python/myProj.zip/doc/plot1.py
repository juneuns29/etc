import matplotlib.pyplot as plt

plt.plot([3, 2, 6, 4, 5])
plt.show()